package main.Chat;

public class ChattingUser {
	
	public String userid;
	public String username;	
	public ChattingUser(String userid,String  username) {
		  // TODO Auto-generated constructor stub
		   		 
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return username;
	}
		
}
